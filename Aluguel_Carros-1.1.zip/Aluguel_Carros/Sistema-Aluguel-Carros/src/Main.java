
import java.sql.Connection;
import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        Connection connect = ConexaoBD.conectar();
        Scanner scanner = new Scanner(System.in);

        if (connect != null) {
            // Você pode usar a conexão aqui para executar queries
            System.out.println("Tudo certo para usar o banco!");
        } else {
            System.out.println("A conexão falhou.");
        }

        // Menu de opções
        int opcao;
        do {
            System.out.println("\n=== MENU ===");
            System.out.println("1 - Cadastrar Carro");
            System.out.println("2 - Exibir Carros");
            System.out.println("3 - Cadastrar Cliente");
            System.out.println("4 - Nota Aluguel");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            switch (opcao) {
                case 1:
                    Carros.cadastrarCarros();
                    break;
                case 2:
                    Carros.exibirCarros();
                    break;
                case 3:
                    Cliente.cadastrarCliente();
                break;
                case 4:
                    Aluguel.exibirAluguel();
                break;
                case 0:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);

        scanner.close();
    }
}