import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Aluguel extends Cliente {
    LocalDate dataRetirada;
    LocalDate dataEntrega;

    public Aluguel(String nome, String cpf, String telefone, String modelo, int ano, double valorDiaria,
                   LocalDate dataRetirada, LocalDate dataEntrega) {
        super(nome, cpf, telefone, modelo, ano, valorDiaria);
        this.dataRetirada = dataRetirada;
        this.dataEntrega = dataEntrega;
    }

    @Override
    public void exibirInfo() {
        System.out.println("===== NOTA DE ALUGUEL =====");
        System.out.println("Cliente: " + nome);
        System.out.println("CPF: " + cpf);
        System.out.println("Telefone: " + telefone);
        System.out.println("Carro: " + modelo + " | Ano: " + ano);
        System.out.println("Data de retirada: " + dataRetirada);
        System.out.println("Data de entrega: " + dataEntrega);
        long dias = ChronoUnit.DAYS.between(dataRetirada, dataEntrega);
        if (dias == 0) dias = 1; // mínimo 1 diária
        double total = dias * valorDiaria;
        System.out.println("Valor da diária: R$" + valorDiaria);
        System.out.println("Total de dias: " + dias);
        System.out.println("Valor total: R$" + total);
        System.out.println("===========================");
    }

    public static void exibirAluguel() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o ID do aluguel: ");
        int aluguelId = scanner.nextInt();

        String sql = "SELECT a.id, c.nome, c.cpf, c.telefone, ca.modelo, ca.ano, ca.valor_diaria, " +
                     "a.data_retirada, a.data_entrega, a.valor_total " +
                     "FROM alugueis a " +
                     "JOIN clientes c ON a.cliente_id = c.id " +
                     "JOIN carros ca ON a.carro_id = ca.id " +
                     "WHERE a.id = ?";

        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(sql)) {
            pstmt.setInt(1, aluguelId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("===== NOTA DE ALUGUEL =====");
                System.out.println("ID do aluguel: " + rs.getInt("id"));
                System.out.println("Cliente: " + rs.getString("nome"));
                System.out.println("CPF: " + rs.getString("cpf"));
                System.out.println("Telefone: " + rs.getString("telefone"));
                System.out.println("Carro: " + rs.getString("modelo") + " | Ano: " + rs.getInt("ano"));
                System.out.println("Data de retirada: " + rs.getDate("data_retirada"));
                System.out.println("Data de entrega: " + rs.getDate("data_entrega"));
                System.out.println("Valor da diária: R$" + rs.getDouble("valor_diaria"));
                System.out.println("Valor total: R$" + rs.getDouble("valor_total"));
                System.out.println("===========================");
            } else {
                System.out.println("Aluguel não encontrado!");
            }
        } catch (Exception e) {
            System.out.println("Erro ao exibir aluguel: " + e.getMessage());
        }
    }
}
