import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Carros {

    private static int proximoId = 1;
    int id;
    String modelo;
    int ano;

    public Carros(String modelo, int ano) {

        this.id = proximoId++; // Auto-incremento
        this.modelo = modelo;
        this.ano = ano;
    }

    // Método que será chamado quando o usuário escolher a opção 1
    public static void cadastrarCarros() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o modelo do carro: ");
        String modelo = scanner.nextLine();

        System.out.print("Digite o ano do carro: ");
        int ano = scanner.nextInt();

        String sql = "INSERT INTO carros(modelo, ano) VALUES (?, ?)";
        try (Connection connect = ConexaoBD.conectar();
                PreparedStatement pstmt = connect.prepareStatement(sql)) {
            pstmt.setString(1, modelo);
            pstmt.setInt(2, ano);
            pstmt.executeUpdate();
            System.out.println("Carro cadastrado com sucesso!");
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar carro: " + e.getMessage());
        }
    }

    public static void exibirCarros() {
        String sql = "SELECT id, modelo, ano FROM carros";
        try (Connection conn = ConexaoBD.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("\nCarros cadastrados:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Modelo: " + rs.getString("modelo") +
                                   ", Ano: " + rs.getInt("ano"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao exibir carros: " + e.getMessage());
        }
    }

}


