import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class UsuarioController {
    
    public static void cadastrarUsuario() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite o nome completo do usuário: ");
        String nome = scanner.nextLine();
        
        System.out.print("Digite o login do usuário: ");
        String login = scanner.nextLine();
        
        System.out.print("Digite a senha do usuário: ");
        String senha = scanner.nextLine();
        
        System.out.print("Digite o perfil do usuário (1 - Dono, 2 - Atendente): ");
        String perfil = scanner.nextLine();
        
        // Verifica se login já existe
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement checkStmt = connect.prepareStatement("SELECT id FROM usuarios WHERE login = ?")) {
            checkStmt.setString(1, login);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                System.out.println("Login já existe. Escolha outro login.");
                return;
            }
        } catch (Exception e) {
            System.out.println("Erro ao verificar login: " + e.getMessage());
            return;
        }
        
        if (perfil.equals("1")) {
            // Só ADMINISTRADOR pode cadastrar Dono
            if (!Main.usuarioLogadoNome.equalsIgnoreCase("ADMINISTRADOR")) {
                System.out.println("Apenas o ADMINISTRADOR pode cadastrar outro Dono.");
                return;
            }
        }
        
        // Insere novo usuário
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(
                "INSERT INTO usuarios (nome, login, senha, perfil) VALUES (?, ?, ?, ?)")) {
            pstmt.setString(1, nome);
            pstmt.setString(2, login);
            pstmt.setString(3, senha);
            pstmt.setInt(4, Integer.parseInt(perfil));
            pstmt.executeUpdate();
            System.out.println("Usuário cadastrado com sucesso!");
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar usuário: " + e.getMessage());
        }
    }
}
