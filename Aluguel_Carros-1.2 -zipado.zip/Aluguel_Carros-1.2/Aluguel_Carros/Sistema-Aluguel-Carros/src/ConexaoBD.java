import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {

    // Método que retorna a conexão com o banco de dados
    public static Connection conectar() {
        Connection connect = null;

        // URL do banco de dados
        String url = "jdbc:mysql://localhost:3306/aluguel_carros"; // Troque pelo nome do seu banco
        String usuario = "root"; // usuário do MySQL
        String senha = ""; // senha do MySQL

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Garante o carregamento do driver
            connect = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexão bem-sucedida!");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver MySQL não encontrado!");
        } catch (SQLException e) {
            System.out.println("Erro ao conectar: " + e.getMessage());
        }
        return connect;
    }
}
