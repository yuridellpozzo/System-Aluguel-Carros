import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;


// Cliente herda de Carros
public class Cliente extends Carros {
    String nome;
    String cpf;
    String telefone;

    public Cliente(String nome, String cpf, String telefone, String modelo, int ano, double valorDiaria) {
        super(modelo, ano, valorDiaria);
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    @Override
    public void exibirInfo() {
        System.out.println("Cliente: " + nome + " | CPF: " + cpf + " | Telefone: " + telefone);
        super.exibirInfo();
    }

    public static void cadastrarCliente() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nome do cliente: ");
        String nome = scanner.nextLine();

        System.out.print("CPF do cliente: ");
        String cpf = scanner.nextLine();

        System.out.print("Telefone do cliente: ");
        String telefone = scanner.nextLine();

        // Cria objeto Cliente temporário para exibir os dados
        Cliente clienteTemp = new Cliente(nome, cpf, telefone, "", 0, 0.0);
        System.out.println("\nConfira os dados digitados:");
        clienteTemp.exibirInfo();

        System.out.print("Deseja salvar este cliente? (s/n): ");
        String confirma = scanner.nextLine();

        if (confirma.equalsIgnoreCase("s")) {
            String sql = "INSERT INTO clientes(nome, cpf, telefone) VALUES (?, ?, ?)";
            try (Connection connect = ConexaoBD.conectar();
                 PreparedStatement pstmt = connect.prepareStatement(sql)) {
                pstmt.setString(1, nome);
                pstmt.setString(2, cpf);
                pstmt.setString(3, telefone);
                pstmt.executeUpdate();
                System.out.println("Cliente cadastrado com sucesso!");
            } catch (Exception e) {
                System.out.println("Erro ao cadastrar cliente: " + e.getMessage());
            }
        } else {
            System.out.println("Cadastro cancelado.");
        }
    }
}
