import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Carros {

    private static int proximoId = 1;
    int id;
    String modelo;
    int ano;
    double valorDiaria; // Valor da diária do carro

    public Carros(String modelo, int ano, double valorDiaria) {

        this.id = proximoId++; // Auto-incremento
        this.modelo = modelo;
        this.ano = ano;
        this.valorDiaria = valorDiaria;
    }

    // Método que será chamado quando o usuário escolher a opção 1
    public static void cadastrarCarros() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Modelo do carro: ");
        String modelo = scanner.nextLine();

        System.out.print("Ano do carro: ");
        int ano = scanner.nextInt();

        System.out.print("Valor da diária: ");
        double valorDiaria = scanner.nextDouble();
        scanner.nextLine(); // Limpa o buffer

        String sql = "INSERT INTO carros (modelo, ano, valor_diaria) VALUES (?, ?, ?)";
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(sql)) {
            pstmt.setString(1, modelo);
            pstmt.setInt(2, ano);
            pstmt.setDouble(3, valorDiaria);
            pstmt.executeUpdate();
            System.out.println("Carro cadastrado com sucesso!");
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar carro: " + e.getMessage());
        }
    }

    public static void exibirCarros() {
        String sql = "SELECT id, modelo, ano, valor_diaria FROM carros";
        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            System.out.println("=== LISTA DE CARROS ===");
            while (rs.next()) {
                System.out.println(
                    "ID: " + rs.getInt("id") +
                    " | Modelo: " + rs.getString("modelo") +
                    " | Ano: " + rs.getInt("ano") +
                    " | Diária: R$" + rs.getDouble("valor_diaria")
                );
            }
        } catch (Exception e) {
            System.out.println("Erro ao exibir carros: " + e.getMessage());
        }
    }

    public void exibirInfo() {
        System.out.println("Carro: " + modelo + " | Ano: " + ano + " | Diária: R$" + valorDiaria);
    }

    public static void excluirCarro() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o ID do carro que deseja excluir: ");
        int carroId = scanner.nextInt();
        scanner.nextLine();

        // Busca e exibe as informações do carro
        String sqlBusca = "SELECT modelo, ano, valor_diaria FROM carros WHERE id = ?";
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(sqlBusca)) {
            pstmt.setInt(1, carroId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Carro encontrado:");
                System.out.println("Modelo: " + rs.getString("modelo"));
                System.out.println("Ano: " + rs.getInt("ano"));
                System.out.println("Valor da diária: R$" + rs.getDouble("valor_diaria"));
            } else {
                System.out.println("Carro não encontrado.");
                return;
            }
        } catch (Exception e) {
            System.out.println("Erro ao buscar carro: " + e.getMessage());
            return;
        }

        // Verifica se o carro está alugado (existe aluguel em andamento para esse carro)
        String sqlVerifica = "SELECT COUNT(*) FROM alugueis WHERE carro_id = ? AND status = 'Em Andamento'";
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(sqlVerifica)) {
            pstmt.setInt(1, carroId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                System.out.println("Não é possível excluir: o carro está alugado ou com aluguel em andamento.");
                return;
            }
        } catch (Exception e) {
            System.out.println("Erro ao verificar status do carro: " + e.getMessage());
            return;
        }

        // Confirmação antes de excluir
        System.out.print("Deseja realmente excluir este carro? (s/n): ");
        String confirma = scanner.nextLine();
        if (!confirma.equalsIgnoreCase("s")) {
            System.out.println("Operação cancelada.");
            return;
        }

        // Exclui o carro se estiver disponível
        String sqlDelete = "DELETE FROM carros WHERE id = ?";
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(sqlDelete)) {
            pstmt.setInt(1, carroId);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Carro excluído com sucesso!");
            } else {
                System.out.println("Carro não encontrado.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao excluir carro: " + e.getMessage());
        }
    }
}


