import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.Console;
import java.util.Scanner;

public class Main {
    public static String usuarioLogadoNome = null;
    public static String usuarioLogadoPerfil = null;

    public static void main(String args[]) {
        Connection connect = ConexaoBD.conectar();
        Scanner scanner = new Scanner(System.in);

        if (connect != null) {
            System.out.println("Tudo certo para usar o banco!");
        } else {
            System.out.println("A conexão falhou.");
            return;
        }

        // Fluxo de login
        boolean autenticado = false;
        do {
            System.out.println("=== LOGIN ===");
            System.out.print("Login: ");
            String login = scanner.nextLine();

            String senha;
            Console console = System.console();
            if (console != null) {
                char[] senhaChars = console.readPassword("Senha: ");
                senha = new String(senhaChars);
            } else {
                // IDEs geralmente não suportam Console, então leia normalmente
                System.out.print("Senha: ");
                senha = scanner.nextLine();
            }

            String sql = "SELECT nome, perfil FROM usuarios WHERE login = ? AND senha = ?";
            try (PreparedStatement pstmt = connect.prepareStatement(sql)) {
                pstmt.setString(1, login);
                pstmt.setString(2, senha);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    usuarioLogadoNome = rs.getString("nome");
                    usuarioLogadoPerfil = rs.getString("perfil");
                    System.out.println("Bem-vindo, " + usuarioLogadoNome + "!");
                    autenticado = true;
                } else {
                    System.out.println("Login ou senha inválidos. Tente novamente.\n");
                }
            } catch (Exception e) {
                System.out.println("Erro ao autenticar: " + e.getMessage());
            }
        } while (!autenticado);

        // Menu de opções
        int opcao;
        do {
            System.out.println("\n=== MENU ===");
            if (usuarioLogadoPerfil.equals("1")) { // Dono
                System.out.println("1 - Cadastrar Carro");
                System.out.println("2 - Exibir Carros");
                System.out.println("3 - Cadastrar Cliente");
                System.out.println("4 - Cadastrar Aluguel");
                System.out.println("5 - Exibir Aluguel");
                System.out.println("6 - Finalizar Aluguel");
                System.out.println("7 - Cadastrar Usuário");
                System.out.println("8 - Excluir Carro");
                System.out.println("9 - Excluir Usuário");
                System.out.println("0 - Sair");
            } else { // Atendente
                System.out.println("2 - Exibir Carros");
                System.out.println("3 - Cadastrar Cliente");
                System.out.println("4 - Cadastrar Aluguel");
                System.out.println("5 - Exibir Aluguel");
                System.out.println("6 - Finalizar Aluguel");
                System.out.println("0 - Sair");
            }
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            switch (opcao) {
                case 1:
                    if (usuarioLogadoPerfil.equals("1")) {
                        Carros.cadastrarCarros();
                    } else {
                        System.out.println("Acesso negado.");
                    }
                    break;
                case 2:
                    Carros.exibirCarros();
                    break;
                case 3:
                    Cliente.cadastrarCliente();
                    break;
                case 4:
                    Aluguel.cadastrarAluguel();
                    break;
                case 5:
                    Aluguel.exibirAluguel();
                    break;
                case 6:
                    Aluguel.finalizarAluguel();
                    break;
                case 7:
                    if (usuarioLogadoPerfil.equals("1")) {
                        UsuarioController.cadastrarUsuario();
                    } else {
                        System.out.println("Acesso negado.");
                    }
                    break;
                case 8:
                    if (usuarioLogadoPerfil.equals("1")) {
                        Carros.excluirCarro();
                    } else {
                        System.out.println("Acesso negado.");
                    }
                    break;
                case 9:
                    if (usuarioLogadoPerfil.equals("1")) {
                        UsuarioController.excluirUsuario();
                    } else {
                        System.out.println("Acesso negado.");
                    }
                    break;
                case 0:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);

        scanner.close();
    }
}