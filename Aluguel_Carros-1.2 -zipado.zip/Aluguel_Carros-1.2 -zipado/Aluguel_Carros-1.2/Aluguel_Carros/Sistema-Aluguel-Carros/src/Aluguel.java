import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Aluguel extends Cliente {
    LocalDate dataRetirada;
    LocalDate dataEntrega;

    public Aluguel(String nome, String cpf, String telefone, String modelo, int ano, double valorDiaria,
            LocalDate dataRetirada, LocalDate dataEntrega) {
        super(nome, cpf, telefone, modelo, ano, valorDiaria);
        this.dataRetirada = dataRetirada;
        this.dataEntrega = dataEntrega;
    }

    public static void exibirAluguel() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o ID do aluguel: ");
        int aluguelId = scanner.nextInt();

        String sql = "SELECT a.id, c.nome, c.cpf, c.telefone, ca.modelo, ca.ano, ca.valor_diaria, " +
                "a.data_retirada, a.data_entrega, a.valor_total, a.status, a.usuario_cadastro, a.usuario_finalizacao " +
                "FROM alugueis a " +
                "JOIN clientes c ON a.cliente_id = c.id " +
                "JOIN carros ca ON a.carro_id = ca.id " +
                "WHERE a.id = ?";

        try (Connection connect = ConexaoBD.conectar();
                PreparedStatement pstmt = connect.prepareStatement(sql)) {
            pstmt.setInt(1, aluguelId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                System.out.println("===== NOTA DE ALUGUEL =====");
                System.out.println("ID do aluguel: " + rs.getInt("id"));
                System.out.println("Cliente: " + rs.getString("nome"));
                System.out.println("CPF: " + rs.getString("cpf"));
                System.out.println("Telefone: " + rs.getString("telefone"));
                System.out.println("Carro: " + rs.getString("modelo") + " | Ano: " + rs.getInt("ano"));
                System.out.println("Data de retirada: " + rs.getDate("data_retirada").toLocalDate().format(formatter));
                System.out.println("Data de entrega: " + rs.getDate("data_entrega").toLocalDate().format(formatter));
                System.out.println("Valor da diária: R$" + rs.getDouble("valor_diaria"));
                System.out.println("Valor total: R$" + rs.getDouble("valor_total"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("Cadastrado por: " + rs.getString("usuario_cadastro"));
                System.out.println("Finalizado por: " + rs.getString("usuario_finalizacao"));
                System.out.println("===========================");
            } else {
                System.out.println("Aluguel não encontrado!");
            }
        } catch (Exception e) {
            System.out.println("Erro ao exibir aluguel: " + e.getMessage());
        }
    }

    public static void cadastrarAluguel() {
        Scanner scanner = new Scanner(System.in);

        // Buscar cliente
        System.out.print("Digite o CPF do cliente: ");
        String cpfBusca = scanner.nextLine();

        String nome = "", cpf = "", telefone = "";
        int clienteId = 0;
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement("SELECT id, nome, cpf, telefone FROM clientes WHERE cpf = ?")) {
            pstmt.setString(1, cpfBusca);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                clienteId = rs.getInt("id");
                nome = rs.getString("nome");
                cpf = rs.getString("cpf");
                telefone = rs.getString("telefone");
            } else {
                System.out.println("Cliente não encontrado!");
                return;
            }
        } catch (Exception e) {
            System.out.println("Erro ao buscar cliente: " + e.getMessage());
            return;
        }

        // Buscar carro
        System.out.print("Digite o ID do carro: ");
        int carroId = scanner.nextInt();
        scanner.nextLine();

        String modelo = "";
        int ano = 0;
        double valorDiaria = 0.0;
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement("SELECT modelo, ano, valor_diaria FROM carros WHERE id = ?")) {
            pstmt.setInt(1, carroId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                modelo = rs.getString("modelo");
                ano = rs.getInt("ano");
                valorDiaria = rs.getDouble("valor_diaria");
            } else {
                System.out.println("Carro não encontrado!");
                return;
            }
        } catch (Exception e) {
            System.out.println("Erro ao buscar carro: " + e.getMessage());
            return;
        }

        // Datas
        System.out.print("Data de retirada (AAAA-MM-DD): ");
        LocalDate dataRetirada = LocalDate.parse(scanner.nextLine());
        System.out.print("Data de entrega (AAAA-MM-DD): ");
        LocalDate dataEntrega = LocalDate.parse(scanner.nextLine());

        long dias = ChronoUnit.DAYS.between(dataRetirada, dataEntrega);
        if (dias == 0) dias = 1;
        double valorTotal = dias * valorDiaria;

        // Inserir aluguel no banco
        String sql = "INSERT INTO alugueis (cliente_id, carro_id, data_retirada, data_entrega, valor_total, status, usuario_cadastro) VALUES (?, ?, ?, ?, ?, 'Em Andamento', ?)";
        try (Connection connect = ConexaoBD.conectar();
             PreparedStatement pstmt = connect.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, clienteId);
            pstmt.setInt(2, carroId);
            pstmt.setDate(3, java.sql.Date.valueOf(dataRetirada));
            pstmt.setDate(4, java.sql.Date.valueOf(dataEntrega));
            pstmt.setDouble(5, valorTotal);
            pstmt.setString(6, Main.usuarioLogadoNome); // <-- Aqui salva o nome do usuário logado
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            int aluguelId = 0;
            if (rs.next()) {
                aluguelId = rs.getInt(1);
            }

            // Exibir nota do aluguel
            System.out.println("\n===== NOTA DE ALUGUEL =====");
            System.out.println("ID do aluguel: " + aluguelId);
            System.out.println("Cliente: " + nome);
            System.out.println("CPF: " + cpf);
            System.out.println("Telefone: " + telefone);
            System.out.println("Carro: " + modelo + " | Ano: " + ano);
            System.out.println("Data de retirada: " + dataRetirada);
            System.out.println("Data de entrega: " + dataEntrega);
            System.out.println("Valor da diária: R$" + valorDiaria);
            System.out.println("Total de dias: " + dias);
            System.out.println("Valor total: R$" + valorTotal);
            System.out.println("Status: Em Andamento");
            System.out.println("Cadastrado por: " + Main.usuarioLogadoNome); // Mostra quem cadastrou
            System.out.println("===========================");
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar aluguel: " + e.getMessage());
        }
    }

    public static void finalizarAluguel() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o ID do aluguel para finalizar: ");
        int aluguelId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Digite 'F' para finalizar o aluguel: ");
        String confirma = scanner.nextLine();

        if (confirma.equalsIgnoreCase("F")) {
            String sql = "UPDATE alugueis SET status = 'Carro Entregue, Aluguel Finalizado', usuario_finalizacao = ? WHERE id = ?";
            try (Connection connect = ConexaoBD.conectar();
                 PreparedStatement pstmt = connect.prepareStatement(sql)) {
                pstmt.setString(1, Main.usuarioLogadoNome); // <-- Aqui salva o nome do usuário logado
                pstmt.setInt(2, aluguelId);
                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    System.out.println("Aluguel finalizado com sucesso por: " + Main.usuarioLogadoNome);
                } else {
                    System.out.println("Aluguel não encontrado!");
                }
            } catch (Exception e) {
                System.out.println("Erro ao finalizar aluguel: " + e.getMessage());
            }
        } else {
            System.out.println("Operação cancelada.");
        }
    }
}
